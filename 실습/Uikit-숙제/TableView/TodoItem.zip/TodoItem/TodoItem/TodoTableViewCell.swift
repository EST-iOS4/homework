//
//  TodoTableViewCell.swift
//  TodoItem
//
//  Created by 송영민 on 8/22/25.
//

import UIKit

class TodoTableViewCell: UITableViewCell {
  
  var checkButton: UIButton!
  var titleLabel: UILabel!
  var priorityView: UIView!
  
  var onToggleComplete: (() -> Void)?

    override func awakeFromNib() {
        super.awakeFromNib()
        
      priorityView.layer.cornerRadius = 4
      checkButton.addTarget(self, action: #selector(toggleComplete), for: .touchUpInside)
    }
  
  func configure(with todo: TodoItem ) {
    titleLabel.text = todo.title
    titleLabel.textColor = todo.isCompleted ? .systemGray : .label
    titleLabel.attributedText = todo.isCompleted ? strikethrough(text: todo.title) : NSAttributedString(string: todo.title)
    
    checkButton.setImage(UIImage(systemName: todo.isCompleted ? "checkmark.circle.fill" : "circle"), for: .normal)
    checkButton.tintColor = todo.isCompleted ? .systemBlue : .systemGray
    
    priorityView.backgroundColor = todo.priority.color
  }
  
  func strikethrough(text: String) -> NSAttributedString {
    let attributedString = NSMutableAttributedString(string: text)
    attributedString.addAttribute(.strikethroughStyle, value: NSUnderlineStyle.single.rawValue, range: NSRange(location: 0, length: text.count))
    return attributedString
  }
  
  @objc func toggleComplete() {
    onToggleComplete?()
  }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }

}
