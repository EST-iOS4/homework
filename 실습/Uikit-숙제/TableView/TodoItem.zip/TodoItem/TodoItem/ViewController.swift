//
//  ViewController.swift
//  TodoItem
//
//  Created by 송영민 on 8/22/25.
//

import UIKit

struct TodoItem {
  var title: String
  var isCompleted: Bool
  var priority: Priority

  enum Priority: Int, CaseIterable {
    case low = 0
    case medium = 1
    case high = 2

    var color: UIColor {
      switch self {
      case .low: return .systemGreen
      case .medium: return .systemYellow
      case .high: return .systemRed

      }
    }
    
    var title: String {
      switch self {
      case .low: return "낮음"
      case .medium: return "보통"
      case .high: return "높음"
      }
    }
  }
} // TodoItem 스트럭트

class ViewController: UIViewController, UITableViewDelegate {
  let tableView: UITableView = {
      let tableView = UITableView(frame: CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height), style: .plain)
      return tableView
    }()
  
  var todos: [TodoItem] = []
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    view.addSubview(tableView)
    
    
    tableView.delegate = self
    
    setupNavigationBar()
    loadSampleData()
    
  }
  
  func setupNavigationBar() {
    navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addTodo))
  }
  
  @objc func addTodo() {
    let alert = UIAlertController(title: "새 할 일", message: nil, preferredStyle: .alert)
    
    alert.addTextField { UITextField in
      UITextField.placeholder = "할 일을 입력하세요."
    }
    
    let saveAciton = UIAlertAction(title: "저장", style: .default) { _ in
      guard let text = alert.textFields?.first?.text, !text.isEmpty else { return }
      
      let newTodo = TodoItem(title: text, isCompleted: false, priority: .medium)
      self.todos.append(newTodo)
      let indexPath = IndexPath(row: self.todos.count - 1, section: 0)
      self.tableView.insertRows(at: [indexPath], with: .automatic)
    }
    
    alert.addAction(saveAciton)
    alert.addAction(UIAlertAction(title: "취소", style: .cancel))
    
    present(alert, animated: true)
  }
  
  func loadSampleData() {
    todos = [
      TodoItem(title: "UITableView 학습하기", isCompleted: true, priority: .high),
      TodoItem(title: "커스텀 셀 만들기", isCompleted: false, priority: .medium),
      TodoItem(title: "스와이프 액션 구하기", isCompleted: false, priority: .low)
    ]
  }
}
  

