//
//  AnimationApp.swift
//  Animation
//
//  Created by 송영민 on 8/7/25.
//

import SwiftUI

@main
struct AnimationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
