//
//  GeometryReaderApp.swift
//  GeometryReader
//
//  Created by 송영민 on 8/7/25.
//

import SwiftUI

@main
struct GeometryReaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
