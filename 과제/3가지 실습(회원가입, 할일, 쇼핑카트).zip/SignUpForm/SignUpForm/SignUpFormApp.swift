//
//  SignUpFormApp.swift
//  SignUpForm
//
//  Created by 송영민 on 8/7/25.
//

import SwiftUI

@main
struct SignUpFormApp: App {
    var body: some Scene {
        WindowGroup {
            SignUpForm()
        }
    }
}
