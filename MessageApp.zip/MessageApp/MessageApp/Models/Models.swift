//
//  Models.swift
//  MessageApp
//
//  Created by 송영민 on 8/28/25.
//

import UIKit

struct Message: Hashable {
    let text: String
    let isMyMessage: Bool
    let timestamp: Date
}
